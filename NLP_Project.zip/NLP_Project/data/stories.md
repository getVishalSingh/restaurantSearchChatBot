## Generated Story 8180122779451640837
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_lt": "700"}
    - slot{"price_lt": "700"}
    - action_restaurant
    - slot{"mail_response": "Found Byg Brewski Brewing Company in Behind MK Retail, Sarjapur Road, Bangalorewith an average budget for two as1600has been rated4.9\nFound Brew and Barbeque - A Microbrewery Pub in 36/4, Fourth Floor, Soul Space Arena, Outer Ring Road, Doddanekkundi Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.9\nFound The Black Pearl in 20/7, Swamy Legato, Outer Ring Road, Kadubeesanahalli, Marathahalli, Bangalorewith an average budget for two as1500has been rated4.9\nFound Big Pitcher in LR Arcade,4121, Old Airport Road, Bangalorewith an average budget for two as2000has been rated4.8\nFound House Of Commons in 122/B, Jyothi Nivas Road, 5th Block, Koramangala 5th Block, Bangalorewith an average budget for two as1000has been rated4.8\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found Byg Brewski Brewing Company in Behind MK Retail, Sarjapur Road, Bangalorewith an average budget for two as1600has been rated4.9\nFound Brew and Barbeque - A Microbrewery Pub in 36/4, Fourth Floor, Soul Space Arena, Outer Ring Road, Doddanekkundi Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.9\nFound The Black Pearl in 20/7, Swamy Legato, Outer Ring Road, Kadubeesanahalli, Marathahalli, Bangalorewith an average budget for two as1500has been rated4.9\nFound Big Pitcher in LR Arcade,4121, Old Airport Road, Bangalorewith an average budget for two as2000has been rated4.8\nFound House Of Commons in 122/B, Jyothi Nivas Road, 5th Block, Koramangala 5th Block, Bangalorewith an average budget for two as1000has been rated4.8\nFound TBC Sky Lounge in Astra Hotel, 2795, 27th Main, Sector 1, HSR Layout, Bangalorewith an average budget for two as1000has been rated4.8\nFound AB's - Absolute Barbecues in 90/4, 3rd Floor, Outer Ring Road, Munnekollaly Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.8\nFound Biergarten in 2, Doddanekkundi, Whitefield Road, Mahadevpura, Whitefield, Bangalorewith an average budget for two as1500has been rated4.8\nFound The Globe Grub in 2nd Floor, Soul Space Paradigm,\nLandmark- Next to Innovative Multiplex, Above Bata Showroom, Outer Ring Road Marathahalli, Bangalorewith an average budget for two as1300has been rated4.8\nFound AB's - Absolute Barbecues in 100 Feet Road, 1st Phase, Near Jayadeva Flyover, 2nd Stage, BTM, Bangalorewith an average budget for two as1400has been rated4.8\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story -8858372447379116646
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Pune"}
    - slot{"location": "Pune"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_lt": "700"}
    - slot{"price_lt": "700"}
    - action_restaurant
    - slot{"mail_response": "Found AB's - Absolute Barbecues in 206, 2nd Floor White Square Building, Opposite Atlanta Complex Hinjewadi, Hinjawadi, Punewith an average budget for two as1400has been rated4.9\nFound Sentosa MultiCuisine Restaurant in Pune-Mumbai Expressway, Ravet, Pune, Punewith an average budget for two as1200has been rated4.9\nFound Gong in Shop 22/23, Balewadi High Street, Cummins India Office Campus, Baner- Balewadi Link Road, Baner, Punewith an average budget for two as1800has been rated4.8\nFound AB's - Absolute Barbecues in Shop 10, 11 & 12, Mariplex Mall, Kalyani Nagar, Punewith an average budget for two as1400has been rated4.8\nFound Mughal Mahal in 153/3, Phase 1, RGIT Park, Marunji Road, Near HP Petrol Pump, Hinjawadi, Punewith an average budget for two as850has been rated4.7\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found AB's - Absolute Barbecues in 206, 2nd Floor White Square Building, Opposite Atlanta Complex Hinjewadi, Hinjawadi, Punewith an average budget for two as1400has been rated4.9\nFound Sentosa MultiCuisine Restaurant in Pune-Mumbai Expressway, Ravet, Pune, Punewith an average budget for two as1200has been rated4.9\nFound Gong in Shop 22/23, Balewadi High Street, Cummins India Office Campus, Baner- Balewadi Link Road, Baner, Punewith an average budget for two as1800has been rated4.8\nFound AB's - Absolute Barbecues in Shop 10, 11 & 12, Mariplex Mall, Kalyani Nagar, Punewith an average budget for two as1400has been rated4.8\nFound Mughal Mahal in 153/3, Phase 1, RGIT Park, Marunji Road, Near HP Petrol Pump, Hinjawadi, Punewith an average budget for two as850has been rated4.7\nFound Agent Jack's in Ground Floor, Kapila Matrix, Koregaon Park Annexe, Mundhwa, Punewith an average budget for two as1300has been rated4.7\nFound Cafe 1730 in 21/1, Serene Bay, Lane 6, Off North Main Road, Koregaon Park, Punewith an average budget for two as1500has been rated4.6\nFound Darshan in 759/60, Prabhat Road, Opposite Indian Bank, Deccan Gymkhana, Punewith an average budget for two as700has been rated4.6\nFound La Gustosa in Survey 1/3 4, Behind Karve Putla, Shivaji Putla Road, Beside DNS Bank, Kothrud, Punewith an average budget for two as700has been rated4.6\nFound Effingut Brewerkz in End of Lane Number 6, Koregaon Park, Punewith an average budget for two as1700has been rated4.6\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story 1759236982580858338
* greet
    - utter_greet
* restaurant_search{"location": "muzaffarpur"}
    - slot{"location": "muzaffarpur"}
    - action_location
    - slot{"location_match": "out"}
    - utter_outofscopelocation
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_lt": "700"}
    - slot{"price_lt": "700"}
    - action_restaurant
    - slot{"mail_response": "Found Feel ALIVE in SCO 53, 2nd Floor, Main Market, Sector 29, Gurgaonwith an average budget for two as1200has been rated4.9\nFound Ministry Of Beer in M 43, Outer Circle, Connaught Place, New Delhiwith an average budget for two as1500has been rated4.9\nFound Phonebooth Reloaded in G14b, Ground Floor, Vijay Nagar, Hudson lane, Delhi University-GTB Nagar, New Delhiwith an average budget for two as1000has been rated4.9\nFound Mellow Garden in J2/7, 2nd & 3rd Floor, BK Dutta Market, Rajouri Garden, New Delhiwith an average budget for two as1200has been rated4.9\nFound 38 Barracks in M-38, Outer Circle, Opposite Shankar Market, Connaught Place, New Delhiwith an average budget for two as1600has been rated4.8\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found Feel ALIVE in SCO 53, 2nd Floor, Main Market, Sector 29, Gurgaonwith an average budget for two as1200has been rated4.9\nFound Ministry Of Beer in M 43, Outer Circle, Connaught Place, New Delhiwith an average budget for two as1500has been rated4.9\nFound Phonebooth Reloaded in G14b, Ground Floor, Vijay Nagar, Hudson lane, Delhi University-GTB Nagar, New Delhiwith an average budget for two as1000has been rated4.9\nFound Mellow Garden in J2/7, 2nd & 3rd Floor, BK Dutta Market, Rajouri Garden, New Delhiwith an average budget for two as1200has been rated4.9\nFound 38 Barracks in M-38, Outer Circle, Opposite Shankar Market, Connaught Place, New Delhiwith an average budget for two as1600has been rated4.8\nFound The Hook in SCO 30, Sector 29, Gurgaonwith an average budget for two as1600has been rated4.8\nFound Burma Burma in S 25, Second Floor, A 3, Select Citywalk Mall, Saket, New Delhiwith an average budget for two as1500has been rated4.8\nFound Orient Heritage in 90/61B, Malviya Nagar Marketwith an average budget for two as850has been rated4.8\nFound CIA Call it Asiian in 16, Narmada Shopping Complex,Opposite Don Bosco School, Greater Kailash 2 (GK2), New Delhiwith an average budget for two as800has been rated4.8\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story -5149166810383262687
* greet
    - utter_greet
* restaurant_search{"location": "Kolkata"}
    - slot{"location": "Kolkata"}
    - action_location
    - slot{"location_match": "out"}
    - utter_outofscopelocation
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": ""}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": ""}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story 1756075397472647420
* greet
    - utter_greet
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - utter_ask_pricerange
* restaurant_search{"price_lt": "700"}
    - slot{"price_lt": "700"}
    - action_restaurant
    - slot{"mail_response": "Found Feel ALIVE in SCO 53, 2nd Floor, Main Market, Sector 29, Gurgaonwith an average budget for two as1200has been rated4.9\nFound Ministry Of Beer in M 43, Outer Circle, Connaught Place, New Delhiwith an average budget for two as1500has been rated4.9\nFound Phonebooth Reloaded in G14b, Ground Floor, Vijay Nagar, Hudson lane, Delhi University-GTB Nagar, New Delhiwith an average budget for two as1000has been rated4.9\nFound Mellow Garden in J2/7, 2nd & 3rd Floor, BK Dutta Market, Rajouri Garden, New Delhiwith an average budget for two as1200has been rated4.9\nFound 38 Barracks in M-38, Outer Circle, Opposite Shankar Market, Connaught Place, New Delhiwith an average budget for two as1600has been rated4.8\nFound The Hook in SCO 30, Sector 29, Gurgaonwith an average budget for two as1600has been rated4.8\nFound Burma Burma in S 25, Second Floor, A 3, Select Citywalk Mall, Saket, New Delhiwith an average budget for two as1500has been rated4.8\nFound Sanadige in 22/48, Commercial Centre, Chanakyapuri, New Delhiwith an average budget for two as2200has been rated4.8\nFound Orient Heritage in 90/61B, Malviya Nagar Marketwith an average budget for two as850has been rated4.8\nFound CIA Call it Asiian in 16, Narmada Shopping Complex,Opposite Don Bosco School, Greater Kailash 2 (GK2), New Delhiwith an average budget for two as800has been rated4.8\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found Feel ALIVE in SCO 53, 2nd Floor, Main Market, Sector 29, Gurgaonwith an average budget for two as1200has been rated4.9\nFound Ministry Of Beer in M 43, Outer Circle, Connaught Place, New Delhiwith an average budget for two as1500has been rated4.9\nFound Phonebooth Reloaded in G14b, Ground Floor, Vijay Nagar, Hudson lane, Delhi University-GTB Nagar, New Delhiwith an average budget for two as1000has been rated4.9\nFound Mellow Garden in J2/7, 2nd & 3rd Floor, BK Dutta Market, Rajouri Garden, New Delhiwith an average budget for two as1200has been rated4.9\nFound 38 Barracks in M-38, Outer Circle, Opposite Shankar Market, Connaught Place, New Delhiwith an average budget for two as1600has been rated4.8\nFound The Hook in SCO 30, Sector 29, Gurgaonwith an average budget for two as1600has been rated4.8\nFound Burma Burma in S 25, Second Floor, A 3, Select Citywalk Mall, Saket, New Delhiwith an average budget for two as1500has been rated4.8\nFound Sanadige in 22/48, Commercial Centre, Chanakyapuri, New Delhiwith an average budget for two as2200has been rated4.8\nFound Orient Heritage in 90/61B, Malviya Nagar Marketwith an average budget for two as850has been rated4.8\nFound CIA Call it Asiian in 16, Narmada Shopping Complex,Opposite Don Bosco School, Greater Kailash 2 (GK2), New Delhiwith an average budget for two as800has been rated4.8\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story 3099519223667819245
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mubaim"}
    - slot{"location": "mubaim"}
    - action_location
    - slot{"location_match": "zero"}
    - utter_invalidlocation
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300", "price_lt": "700"}
    - slot{"price_lt": "700"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Found Kokani Katta in Shop 8, 9 Jangid Arcadia, Jangid Enclave Near Bhairav Residency, Kanakia Road, Mira Road, Mumbaiwith an average budget for two as700has been rated4.9\nFound The Dough Code in 10, Ground Floor, Mount Building, JP Road, Jeet Nagar, Versova, Andheri West, Mumbaiwith an average budget for two as500has been rated4.9\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found Kokani Katta in Shop 8, 9 Jangid Arcadia, Jangid Enclave Near Bhairav Residency, Kanakia Road, Mira Road, Mumbaiwith an average budget for two as700has been rated4.9\nFound The Dough Code in 10, Ground Floor, Mount Building, JP Road, Jeet Nagar, Versova, Andheri West, Mumbaiwith an average budget for two as500has been rated4.9\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story -3471600705889414760
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "chandigarh"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "chandigarh"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Found O Chicken India -  Oil Free Healthy Chicken in Bay Shop 15, Sector 18-D, Chandigarh, Sector 18, Chandigarhwith an average budget for two as300has been rated4.2\n"}
    - utter_ask_tomail
* reject
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story -2864101691119841799
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Could not find restaurants in the price range."}
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story -2301329028477846414
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - utter_ask_pricerange
* restaurant_search{"price_lt": "700"}
    - slot{"price_lt": "700"}
    - action_restaurant
    - slot{"mail_response": "Found Byg Brewski Brewing Company in Behind MK Retail, Sarjapur Road, Bangalorewith an average budget for two as1600has been rated4.9\nFound Brew and Barbeque - A Microbrewery Pub in 36/4, Fourth Floor, Soul Space Arena, Outer Ring Road, Doddanekkundi Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.9\nFound The Black Pearl in 20/7, Swamy Legato, Outer Ring Road, Kadubeesanahalli, Marathahalli, Bangalorewith an average budget for two as1500has been rated4.9\nFound Punjab Grill in 26/1, Dr. Rajkumar Road, In Brigade Gateway Campus, Malleshwaram ,Bangalorewith an average budget for two as2000has been rated4.9\nFound AB's - Absolute Barbecues in 2nd Floor,I20-A2, EPIP Zone, Near Vydehi Hospital Whitefield, Bangalorewith an average budget for two as1400has been rated4.9\nFound Big Pitcher in LR Arcade,4121, Old Airport Road, Bangalorewith an average budget for two as2000has been rated4.8\nFound House Of Commons in 122/B, Jyothi Nivas Road, 5th Block, Koramangala 5th Block, Bangalorewith an average budget for two as1000has been rated4.8\nFound TBC Sky Lounge in Astra Hotel, 2795, 27th Main, Sector 1, HSR Layout, Bangalorewith an average budget for two as1000has been rated4.8\nFound AB's - Absolute Barbecues in 90/4, 3rd Floor, Outer Ring Road, Munnekollaly Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.8\nFound Biergarten in 2, Doddanekkundi, Whitefield Road, Mahadevpura, Whitefield, Bangalorewith an average budget for two as1500has been rated4.8\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found Byg Brewski Brewing Company in Behind MK Retail, Sarjapur Road, Bangalorewith an average budget for two as1600has been rated4.9\nFound Brew and Barbeque - A Microbrewery Pub in 36/4, Fourth Floor, Soul Space Arena, Outer Ring Road, Doddanekkundi Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.9\nFound The Black Pearl in 20/7, Swamy Legato, Outer Ring Road, Kadubeesanahalli, Marathahalli, Bangalorewith an average budget for two as1500has been rated4.9\nFound Punjab Grill in 26/1, Dr. Rajkumar Road, In Brigade Gateway Campus, Malleshwaram ,Bangalorewith an average budget for two as2000has been rated4.9\nFound AB's - Absolute Barbecues in 2nd Floor,I20-A2, EPIP Zone, Near Vydehi Hospital Whitefield, Bangalorewith an average budget for two as1400has been rated4.9\nFound Big Pitcher in LR Arcade,4121, Old Airport Road, Bangalorewith an average budget for two as2000has been rated4.8\nFound House Of Commons in 122/B, Jyothi Nivas Road, 5th Block, Koramangala 5th Block, Bangalorewith an average budget for two as1000has been rated4.8\nFound TBC Sky Lounge in Astra Hotel, 2795, 27th Main, Sector 1, HSR Layout, Bangalorewith an average budget for two as1000has been rated4.8\nFound AB's - Absolute Barbecues in 90/4, 3rd Floor, Outer Ring Road, Munnekollaly Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.8\nFound Biergarten in 2, Doddanekkundi, Whitefield Road, Mahadevpura, Whitefield, Bangalorewith an average budget for two as1500has been rated4.8\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
	
	
## Generated Story -5740485229119535613
* affirm
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Could not find restaurants in the price range."}
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	

	
## Generated Story 689700741829521375
* greet
    - utter_greet
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Could not find restaurants in the price range."}
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
	
	
## Generated Story -2440371638777558053
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mubaim"}
    - slot{"location": "mubaim"}
    - action_location
    - slot{"location_match": "zero"}
    - utter_invalidlocation
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Found Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\nFound Apsara Ice Cream in Shop 1, Nav Meghdoot Society, Opposite Vijay Sales, Khar West, Mumbaiwith an average budget for two as200has been rated4.9\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
	

## Generated Story 5695051598355147975
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "chandigarh"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "chandigarh"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Found O Chicken India -  Oil Free Healthy Chicken in Bay Shop 15, Sector 18-D, Chandigarh, Sector 18, Chandigarhwith an average budget for two as300has been rated4.2\nFound O Chicken India -  Oil Free Healthy Chicken in Bay Shop 15, Sector 18-D, Chandigarh, Sector 18, Chandigarhwith an average budget for two as300has been rated4.2\nFound O Chicken India -  Oil Free Healthy Chicken in Bay Shop 15, Sector 18-D, Chandigarh, Sector 18, Chandigarhwith an average budget for two as300has been rated4.2\nFound O Chicken India -  Oil Free Healthy Chicken in Bay Shop 15, Sector 18-D, Chandigarh, Sector 18, Chandigarhwith an average budget for two as300has been rated4.2\nFound O Chicken India -  Oil Free Healthy Chicken in Bay Shop 15, Sector 18-D, Chandigarh, Sector 18, Chandigarhwith an average budget for two as300has been rated4.2\n"}
    - utter_ask_tomail
* reject
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
## Generated Story 310859822194840216
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_lt": "700"}
    - slot{"price_lt": "700"}
    - action_restaurant
    - slot{"mail_response": "Found Byg Brewski Brewing Company in Behind MK Retail, Sarjapur Road, Bangalorewith an average budget for two as1600has been rated4.9\nFound The Black Pearl in 20/7, Swamy Legato, Outer Ring Road, Kadubeesanahalli, Marathahalli, Bangalorewith an average budget for two as1500has been rated4.9\nFound Brew and Barbeque - A Microbrewery Pub in 36/4, Fourth Floor, Soul Space Arena, Outer Ring Road, Doddanekkundi Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.9\nFound Big Pitcher in LR Arcade,4121, Old Airport Road, Bangalorewith an average budget for two as2000has been rated4.8\nFound House Of Commons in 122/B, Jyothi Nivas Road, 5th Block, Koramangala 5th Block, Bangalorewith an average budget for two as1000has been rated4.8\nFound TBC Sky Lounge in Astra Hotel, 2795, 27th Main, Sector 1, HSR Layout, Bangalorewith an average budget for two as1000has been rated4.8\nFound AB's - Absolute Barbecues in 90/4, 3rd Floor, Outer Ring Road, Munnekollaly Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.8\nFound Biergarten in 2, Doddanekkundi, Whitefield Road, Mahadevpura, Whitefield, Bangalorewith an average budget for two as1500has been rated4.8\nFound The Globe Grub in 2nd Floor, Soul Space Paradigm,\nLandmark- Next to Innovative Multiplex, Above Bata Showroom, Outer Ring Road Marathahalli, Bangalorewith an average budget for two as1300has been rated4.8\nFound AB's - Absolute Barbecues in 100 Feet Road, 1st Phase, Near Jayadeva Flyover, 2nd Stage, BTM, Bangalorewith an average budget for two as1400has been rated4.8\n"}
    - utter_ask_tomail
* reject
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
## Generated Story -5530703336871626112
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "muzaffarpur"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "muzaffarpur"}
    - action_location
    - slot{"location_match": "out"}
    - utter_outofscopelocation
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300", "price_lt": "700"}
    - slot{"price_lt": "700"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Found Punjabi Angithi in Shop 32-22, A-4, DDA Market, Paschim Vihar, New Delhiwith an average budget for two as500has been rated4.8\nFound Foodflix in Rajouri Garden, New Delhiwith an average budget for two as650has been rated4.8\nFound Namaste Asia in 304, Mandi Road, Sultanpur, MG Road, New Delhiwith an average budget for two as600has been rated4.8\nFound Thok (The House of Kakori) in Kalkaji, New Delhiwith an average budget for two as700has been rated4.8\nFound Punjabi Angithi in Shop 32-22, A-4, DDA Market, Paschim Vihar, New Delhiwith an average budget for two as500has been rated4.8\nFound Foodflix in Rajouri Garden, New Delhiwith an average budget for two as650has been rated4.8\nFound Namaste Asia in 304, Mandi Road, Sultanpur, MG Road, New Delhiwith an average budget for two as600has been rated4.8\nFound Thok (The House of Kakori) in Kalkaji, New Delhiwith an average budget for two as700has been rated4.8\nFound Punjabi Angithi in Shop 32-22, A-4, DDA Market, Paschim Vihar, New Delhiwith an average budget for two as500has been rated4.8\nFound Foodflix in Rajouri Garden, New Delhiwith an average budget for two as650has been rated4.8\n"}
    - utter_ask_tomail
* affirm
    - utter_ask_email
* email_provide{"emailid": "getvishalsingh.007@gmail.com"}
    - slot{"emailid": "getvishalsingh.007@gmail.com"}
    - action_mailrestaurantdetails
    - slot{"mail_details": "Found Punjabi Angithi in Shop 32-22, A-4, DDA Market, Paschim Vihar, New Delhiwith an average budget for two as500has been rated4.8\nFound Foodflix in Rajouri Garden, New Delhiwith an average budget for two as650has been rated4.8\nFound Namaste Asia in 304, Mandi Road, Sultanpur, MG Road, New Delhiwith an average budget for two as600has been rated4.8\nFound Thok (The House of Kakori) in Kalkaji, New Delhiwith an average budget for two as700has been rated4.8\nFound Punjabi Angithi in Shop 32-22, A-4, DDA Market, Paschim Vihar, New Delhiwith an average budget for two as500has been rated4.8\nFound Foodflix in Rajouri Garden, New Delhiwith an average budget for two as650has been rated4.8\nFound Namaste Asia in 304, Mandi Road, Sultanpur, MG Road, New Delhiwith an average budget for two as600has been rated4.8\nFound Thok (The House of Kakori) in Kalkaji, New Delhiwith an average budget for two as700has been rated4.8\nFound Punjabi Angithi in Shop 32-22, A-4, DDA Market, Paschim Vihar, New Delhiwith an average budget for two as500has been rated4.8\nFound Foodflix in Rajouri Garden, New Delhiwith an average budget for two as650has been rated4.8\n"}
    - action_sendmail
    - utter_mailsent
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

## Generated Story 8645656397521188764
* greet
    - utter_greet
* restaurant_search{"cuisine": "Italian", "location": "muzaffarpur"}
    - slot{"cuisine": "Italian"}
    - slot{"location": "muzaffarpur"}
    - action_location
    - slot{"location_match": "out"}
    - utter_outofscopelocation
* restaurant_search{"location": "Kolkata"}
    - slot{"location": "Kolkata"}
    - action_location
    - slot{"location_match": "out"}
    - utter_outofscopelocation
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_pricerange
* restaurant_search{"price_lt": "700"}
    - slot{"price_lt": "700"}
    - action_restaurant
    - slot{"mail_response": "Found Byg Brewski Brewing Company in Behind MK Retail, Sarjapur Road, Bangalorewith an average budget for two as1600has been rated4.9\nFound The Black Pearl in 20/7, Swamy Legato, Outer Ring Road, Kadubeesanahalli, Marathahalli, Bangalorewith an average budget for two as1500has been rated4.9\nFound Brew and Barbeque - A Microbrewery Pub in 36/4, Fourth Floor, Soul Space Arena, Outer Ring Road, Doddanekkundi Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.9\nFound Punjab Grill in 26/1, Dr. Rajkumar Road, In Brigade Gateway Campus, Malleshwaram ,Bangalorewith an average budget for two as2000has been rated4.9\nFound AB's - Absolute Barbecues in 2nd Floor,I20-A2, EPIP Zone, Near Vydehi Hospital Whitefield, Bangalorewith an average budget for two as1400has been rated4.9\nFound Big Pitcher in LR Arcade,4121, Old Airport Road, Bangalorewith an average budget for two as2000has been rated4.8\nFound House Of Commons in 122/B, Jyothi Nivas Road, 5th Block, Koramangala 5th Block, Bangalorewith an average budget for two as1000has been rated4.8\nFound TBC Sky Lounge in Astra Hotel, 2795, 27th Main, Sector 1, HSR Layout, Bangalorewith an average budget for two as1000has been rated4.8\nFound AB's - Absolute Barbecues in 90/4, 3rd Floor, Outer Ring Road, Munnekollaly Village, Marathahalli, Bangalorewith an average budget for two as1400has been rated4.8\nFound Biergarten in 2, Doddanekkundi, Whitefield Road, Mahadevpura, Whitefield, Bangalorewith an average budget for two as1500has been rated4.8\n"}
    - utter_ask_tomail
* reject
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
	
	
## Generated Story -2201243100784725181
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300", "price_lt": "700"}
    - slot{"price_lt": "700"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Could not find restaurants in the price range."}
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
## Generated Story 4981823325853386182
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300", "price_lt": "700"}
    - slot{"price_lt": "700"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Could not find restaurants in the price range."}
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	

	
## Generated Story -7795748138958532932
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300", "price_lt": "700"}
    - slot{"price_lt": "700"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Could not find restaurants in the price range."}
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export
	
## Generated Story 7872616929620433815
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_pricerange
* restaurant_search{"price_ut": "300", "price_lt": "700"}
    - slot{"price_lt": "700"}
    - slot{"price_ut": "300"}
    - action_restaurant
    - slot{"mail_response": "Could not find restaurants in the price range."}
    - utter_goodbye
    - action_slot_reset
    - reset_slots
    - export

















